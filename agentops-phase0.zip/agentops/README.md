# AgentOps

**AI Agent Evaluation, Observability & Reliability Platform**

> AgentOps doesn't make agents smarter. It makes their behavior measurable, explainable, and diagnosable.

This repo is being built **phase by phase**. Each phase ends with a working
milestone before the next one starts — see `PHASES.md` for the full plan.

---

## ✅ Phase 0 — Foundation (current)

**Status: complete.**

What exists right now:

- Repo structure (`agents/`, `instrumentation/`, `backend/`, `evaluation/`,
  `failure_analysis/`, `sandbox/`, `benchmarks/`, `frontend/`)
- FastAPI backend exposing CRUD over the core data model
- PostgreSQL schema (SQLAlchemy models): `agents`, `sessions`, `traces`,
  `spans`, `evaluations`, `failures`
- Alembic wired up for future migrations
- The instrumentation interface (`instrumentation/tracer.py`):
  `tracer.start_trace()` → `trace.start_span()` → `span.end()` → `trace.end()`
- The abstract agent interface (`agents/base.py`) that DevPilot and
  ResearchOS will implement in Phase 1 and Phase 4

**No agent logic yet. No dashboard yet.** That's intentional — Phase 0 only
proves the foundation actually works end-to-end.

This was verified with a live smoke test: an agent, a trace, four spans
(planner → pytest fail → debugger → pytest pass), an evaluation, and a
failure record were all created and correctly persisted and retrieved
through the real API and the real `Tracer` client — the exact pattern
DevPilot will use in Phase 1.

---

## Getting started

### 1. Start PostgreSQL

```bash
docker compose up -d
```

### 2. Install dependencies (using `uv`)

```bash
uv sync
cp .env.example .env
# fill in DATABASE_URL (already correct for docker-compose defaults) and any LLM API keys
```

### 3. Run the backend

```bash
uv run uvicorn backend.main:app --reload
```

Visit `http://localhost:8000/docs` for interactive API docs (Swagger UI).
On startup, tables are created automatically via `Base.metadata.create_all`
(Phase 0 only — from Phase 1 onward, use Alembic migrations instead).

### 4. Try it

```bash
# Register an agent
curl -X POST http://localhost:8000/agents/ \
  -H "Content-Type: application/json" \
  -d '{"name": "devpilot", "version": "v1", "description": "coding agent"}'

# Use the Tracer from Python (this is what agents will do internally)
python -c "
from instrumentation.tracer import Tracer
tracer = Tracer(backend_url='http://localhost:8000')
trace = tracer.start_trace(agent_id='<agent-id-from-above>')
span = trace.start_span(name='planner', type='AGENT')
span.end(output={'plan': ['step 1', 'step 2']})
trace.end(status='SUCCESS')
"
```

### 5. Run migrations (once you start changing the schema)

```bash
uv run alembic revision --autogenerate -m "description"
uv run alembic upgrade head
```

---

## Project structure

```text
agentops/
├── agents/              # DevPilot (Phase 1) + ResearchOS (Phase 4) live here
│   ├── base.py           # BaseAgent interface — implemented by both agents
│   ├── devpilot/
│   └── researchos/
├── instrumentation/      # Tracer / Trace / Span — the observability core
│   └── tracer.py
├── backend/              # FastAPI + SQLAlchemy + PostgreSQL
│   ├── main.py
│   ├── database.py
│   ├── models.py         # ORM models: agents, sessions, traces, spans, evaluations, failures
│   ├── schemas.py        # Pydantic request/response schemas
│   └── routers/
├── evaluation/           # Phase 5 — deterministic + LLM-as-judge evaluators
├── failure_analysis/     # Phase 6-7 — failure taxonomy + recovery tracking
├── sandbox/              # Phase 1 — subprocess-based code execution for DevPilot
├── benchmarks/           # Phase 9 — 40-60 real benchmark runs
├── frontend/             # Phase 3+ — Next.js dashboard
├── alembic/              # DB migrations
├── docker-compose.yml    # Local PostgreSQL
└── pyproject.toml
```

## Tech stack

See `PHASES.md` for the full stack breakdown per phase. Summary: Python
3.12 + LangGraph + FastAPI + SQLAlchemy + PostgreSQL + Alembic on the
backend; Next.js + React + Tailwind + shadcn/ui + Recharts + React Flow on
the frontend (starting Phase 3); Docker Compose for local Postgres.

## Next: Phase 1 — DevPilot Core

Build the first working autonomous coding agent: repository tools
(`list_files`, `read_file`, `search_code`, `write_file`, `edit_file`,
`git_diff`), a planner, code generation, `subprocess`-based test execution,
and a debugging/retry loop (max 3 retries). Milestone: DevPilot can take a
real repo task and go plan → inspect → modify → test → debug → retry →
finish — usable even before it's wired into AgentOps's tracing.
