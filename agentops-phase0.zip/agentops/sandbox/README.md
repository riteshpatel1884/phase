Phase 1 execution sandbox (subprocess-based initially)
