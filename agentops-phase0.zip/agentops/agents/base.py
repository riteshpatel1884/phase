"""
Base agent interface (Phase 0).

DevPilot (Phase 1) and ResearchOS (Phase 4) both implement this so that:
  - the instrumentation layer can wrap any agent the same way
  - the evaluation engine can call `evaluate()` generically
  - the backend can register/list agents through a common shape

This file defines the contract only. No agent logic lives here yet.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional

from instrumentation.tracer import Tracer, Trace, tracer as default_tracer


@dataclass
class AgentResult:
    """Standard return shape for any agent run, regardless of task type."""

    success: bool
    output: Any
    trace_id: Optional[str] = None
    retries: int = 0
    metadata: dict = field(default_factory=dict)


class BaseAgent(ABC):
    """
    Every agent in AgentOps (DevPilot, ResearchOS, and any future agent)
    must implement `run()`. Instrumentation is handled by wrapping the
    call in a Trace obtained from the shared Tracer.
    """

    #: Must match the `agents.name` row created for this agent in the DB.
    agent_name: str = "base"

    def __init__(self, agent_id: str, tracer_instance: Optional[Tracer] = None):
        self.agent_id = agent_id
        self.tracer = tracer_instance or default_tracer

    @abstractmethod
    def run(self, task: str, session_id: Optional[str] = None) -> AgentResult:
        """
        Execute the agent on a task end-to-end (plan -> act -> verify/retry
        -> finish) and return an AgentResult.

        Implementations are responsible for:
          - starting a Trace via self.tracer.start_trace(...)
          - opening/closing Spans for each meaningful step
          - ending the Trace with the correct final status
        """
        raise NotImplementedError

    def _start_trace(self, session_id: Optional[str] = None, metadata: Optional[dict] = None) -> Trace:
        return self.tracer.start_trace(
            agent_id=self.agent_id,
            session_id=session_id,
            metadata=metadata or {},
        )
