# AgentOps — Phase Plan

Full phase-by-phase plan (12 phases across a 4-week MVP + Phase 2 follow-up).
This file is the working checklist — check off milestones as they're hit.

- [x] **Phase 0 — Foundation**: repo structure, FastAPI skeleton, PostgreSQL
      schema, trace/span interface, agent interface. *(complete)*
- [ ] **Phase 1 — DevPilot Core**: repo tools, planner, code gen, subprocess
      test execution, debug/retry loop (max 3 retries).
- [ ] **Phase 2 — DevPilot Instrumentation**: wire tracer into every
      DevPilot step (planner, LLM calls, tools, code execution).
- [ ] **Phase 3 — Basic Trace Explorer**: first Next.js frontend — trace
      list + execution tree + span detail view.
- [ ] **Phase 4 — ResearchOS**: Planner / Researcher / Critic-Verifier
      three-role multi-agent system with a self-correction loop.
- [ ] **Phase 5 — Evaluation Engine**: deterministic evaluators + LLM-as-judge
      for both agents.
- [ ] **Phase 6 — Failure Detection & Taxonomy**: classify failures, link to
      trace/span.
- [ ] **Phase 7 — Recovery Analysis**: FAILED → RECOVERY_ATTEMPT →
      RECOVERED/UNRECOVERED state machine.
- [ ] **Phase 8 — Dashboard**: Overview, Trace Explorer, Evaluation,
      Failure Analysis pages.
- [ ] **Phase 9 — Real Benchmarking**: 20-30 real tasks per agent (40-60
      total). No fabricated numbers.
- [ ] **Phase 10 — Result Analysis**: mine the benchmark data for actual
      engineering insights (which tools fail most, does retry help, etc.)
- [ ] **Phase 11 — Regression Testing**: DevPilot v1 vs v2 on identical
      benchmark tasks.
- [ ] **Phase 12 — Advanced Features**: prompt versioning, eval datasets,
      human feedback, Docker sandboxing, anomaly detection. Only after the
      core system is excellent.

**Rule:** don't start the next phase until the current one produces
something you can actually run and test.
