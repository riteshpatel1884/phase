"""
AgentOps instrumentation layer (Phase 0 interface).

This defines the conceptual API from the project spec:

    trace = tracer.start_trace("devpilot")
    span = trace.start_span(name="planner", type="AGENT")
    # ... agent operation ...
    span.end()
    trace.end()

Design notes:
- This is intentionally a thin, synchronous wrapper. Agents (Phase 1+)
  call it directly; there is no external SDK boundary (see spec section 18/25).
- Persistence is via HTTP calls to the AgentOps backend (backend/main.py),
  keeping the agent process decoupled from the database. This mirrors
  how OpenTelemetry/OpenInference exporters work, without adopting their
  full complexity.
- Every span tracks its own start/end time and duration; the tracer just
  manages the parent/child stack so nested spans attach correctly.
"""

from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional

import httpx

DEFAULT_BACKEND_URL = "http://localhost:8000"


class Span:
    """A single traced operation. Created via Trace.start_span()."""

    def __init__(
        self,
        trace: "Trace",
        name: str,
        type: str,
        parent_span_id: Optional[str] = None,
        input: Any = None,
        metadata: Optional[dict] = None,
    ):
        self._trace = trace
        self.name = name
        self.type = type
        self.parent_span_id = parent_span_id
        self.input = input
        self.metadata = metadata or {}

        self.start_time = datetime.utcnow()
        self.end_time: Optional[datetime] = None
        self.status = "RUNNING"
        self.output: Any = None
        self.error: Optional[str] = None

        self.id: Optional[str] = None  # filled in once persisted

        self._t0 = time.perf_counter()
        self._persist_start()

    def _persist_start(self):
        payload = {
            "trace_id": self._trace.id,
            "parent_span_id": self.parent_span_id,
            "type": self.type,
            "name": self.name,
            "input": self.input,
            "span_metadata": self.metadata,
        }
        try:
            resp = self._trace._client.post("/traces/spans/", json=payload)
            resp.raise_for_status()
            self.id = resp.json()["id"]
        except Exception as exc:  # pragma: no cover - defensive, backend may be offline
            self.error = f"span persist_start failed: {exc}"

    def end(self, output: Any = None, error: Optional[str] = None):
        """Mark this span complete and flush the update to the backend."""
        self.end_time = datetime.utcnow()
        self.output = output
        self.error = error or self.error
        self.status = "ERROR" if self.error else "OK"
        duration_ms = (time.perf_counter() - self._t0) * 1000

        if self.id:
            payload = {
                "end_time": self.end_time.isoformat(),
                "status": self.status,
                "output": self.output,
                "error": self.error,
            }
            try:
                self._trace._client.patch(f"/traces/spans/{self.id}", json=payload)
            except Exception:  # pragma: no cover
                pass

        return duration_ms

    @contextmanager
    def context(self):
        """Allows `with span.context():` style usage if preferred over manual end()."""
        try:
            yield self
        except Exception as exc:
            self.end(error=str(exc))
            raise
        else:
            self.end()


class Trace:
    """A complete agent run. Created via Tracer.start_trace()."""

    def __init__(
        self,
        client: httpx.Client,
        agent_id: str,
        session_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ):
        self._client = client
        self.agent_id = agent_id
        self.session_id = session_id
        self.metadata = metadata or {}

        self.status = "RUNNING"
        self.start_time = datetime.utcnow()
        self.end_time: Optional[datetime] = None
        self.total_tokens = 0
        self.total_cost = 0.0

        self.id: Optional[str] = None
        self._span_stack: list[Span] = []
        self._t0 = time.perf_counter()
        self._persist_start()

    def _persist_start(self):
        payload = {
            "agent_id": self.agent_id,
            "session_id": self.session_id,
            "trace_metadata": self.metadata,
        }
        try:
            resp = self._client.post("/traces/", json=payload)
            resp.raise_for_status()
            self.id = resp.json()["id"]
        except Exception as exc:  # pragma: no cover
            print(f"[tracer] failed to create trace: {exc}")

    def start_span(
        self,
        name: str,
        type: str = "AGENT",
        input: Any = None,
        metadata: Optional[dict] = None,
    ) -> Span:
        """Start a span. If called while another span is open, it becomes
        the parent automatically (simple stack-based nesting)."""
        parent_id = self._span_stack[-1].id if self._span_stack else None
        span = Span(self, name=name, type=type, parent_span_id=parent_id, input=input, metadata=metadata)
        self._span_stack.append(span)
        return span

    def end_span(self, span: Span, output: Any = None, error: Optional[str] = None):
        """Convenience method: end a span and pop it off the stack."""
        span.end(output=output, error=error)
        if self._span_stack and self._span_stack[-1] is span:
            self._span_stack.pop()

    def record_llm_usage(self, input_tokens: int, output_tokens: int, cost: float = 0.0):
        """Roll LLM token/cost usage up into the trace total."""
        self.total_tokens += input_tokens + output_tokens
        self.total_cost += cost

    def end(self, status: str = "SUCCESS"):
        self.end_time = datetime.utcnow()
        self.status = status
        latency_ms = (time.perf_counter() - self._t0) * 1000

        if self.id:
            payload = {
                "status": self.status,
                "end_time": self.end_time.isoformat(),
                "total_tokens": self.total_tokens,
                "total_cost": self.total_cost,
                "latency_ms": latency_ms,
            }
            try:
                self._client.patch(f"/traces/{self.id}", json=payload)
            except Exception:  # pragma: no cover
                pass

        return latency_ms


class Tracer:
    """Entry point for instrumentation. One Tracer per process is typical."""

    def __init__(self, backend_url: str = DEFAULT_BACKEND_URL):
        self._client = httpx.Client(base_url=backend_url, timeout=10.0)

    def start_trace(
        self,
        agent_id: str,
        session_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> Trace:
        return Trace(self._client, agent_id=agent_id, session_id=session_id, metadata=metadata)

    def close(self):
        self._client.close()


# Module-level default instance for convenience: `from instrumentation.tracer import tracer`
tracer = Tracer()
