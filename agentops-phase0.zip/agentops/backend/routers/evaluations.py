from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session as DBSession

from backend.database import get_db
from backend import models, schemas

router = APIRouter(prefix="/evaluations", tags=["evaluations"])


@router.post("/", response_model=schemas.EvaluationOut)
def create_evaluation(payload: schemas.EvaluationCreate, db: DBSession = Depends(get_db)):
    trace = db.query(models.Trace).get(payload.trace_id)
    if not trace:
        raise HTTPException(status_code=404, detail="Trace not found")
    evaluation = models.Evaluation(**payload.model_dump())
    db.add(evaluation)
    db.commit()
    db.refresh(evaluation)
    return evaluation


@router.get("/", response_model=list[schemas.EvaluationOut])
def list_evaluations(trace_id: str | None = None, db: DBSession = Depends(get_db)):
    query = db.query(models.Evaluation)
    if trace_id:
        query = query.filter_by(trace_id=trace_id)
    return query.all()
