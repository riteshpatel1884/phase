from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session as DBSession

from backend.database import get_db
from backend import models, schemas

router = APIRouter(prefix="/failures", tags=["failures"])


@router.post("/", response_model=schemas.FailureOut)
def create_failure(payload: schemas.FailureCreate, db: DBSession = Depends(get_db)):
    trace = db.query(models.Trace).get(payload.trace_id)
    if not trace:
        raise HTTPException(status_code=404, detail="Trace not found")
    failure = models.Failure(**payload.model_dump())
    db.add(failure)
    db.commit()
    db.refresh(failure)
    return failure


@router.get("/", response_model=list[schemas.FailureOut])
def list_failures(trace_id: str | None = None, category: str | None = None, db: DBSession = Depends(get_db)):
    query = db.query(models.Failure)
    if trace_id:
        query = query.filter_by(trace_id=trace_id)
    if category:
        query = query.filter_by(category=category)
    return query.all()
