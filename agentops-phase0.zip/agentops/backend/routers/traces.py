from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session as DBSession

from backend.database import get_db
from backend import models, schemas

router = APIRouter(prefix="/traces", tags=["traces"])


# ---------------------------------------------------------------------------
# Traces
# ---------------------------------------------------------------------------

@router.post("/", response_model=schemas.TraceOut)
def create_trace(payload: schemas.TraceCreate, db: DBSession = Depends(get_db)):
    trace = models.Trace(**payload.model_dump())
    db.add(trace)
    db.commit()
    db.refresh(trace)
    return trace


@router.patch("/{trace_id}", response_model=schemas.TraceOut)
def update_trace(trace_id: str, payload: schemas.TraceUpdate, db: DBSession = Depends(get_db)):
    trace = db.query(models.Trace).get(trace_id)
    if not trace:
        raise HTTPException(status_code=404, detail="Trace not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(trace, field, value)
    db.commit()
    db.refresh(trace)
    return trace


@router.get("/", response_model=list[schemas.TraceOut])
def list_traces(agent_id: str | None = None, db: DBSession = Depends(get_db)):
    query = db.query(models.Trace)
    if agent_id:
        query = query.filter_by(agent_id=agent_id)
    return query.order_by(models.Trace.start_time.desc()).all()


@router.get("/{trace_id}", response_model=schemas.TraceOut)
def get_trace(trace_id: str, db: DBSession = Depends(get_db)):
    trace = db.query(models.Trace).get(trace_id)
    if not trace:
        raise HTTPException(status_code=404, detail="Trace not found")
    return trace


@router.get("/{trace_id}/spans", response_model=list[schemas.SpanOut])
def get_trace_spans(trace_id: str, db: DBSession = Depends(get_db)):
    """Returns the full flat span list for a trace; the frontend/tree
    builder reconstructs parent-child nesting from parent_span_id."""
    trace = db.query(models.Trace).get(trace_id)
    if not trace:
        raise HTTPException(status_code=404, detail="Trace not found")
    return (
        db.query(models.Span)
        .filter_by(trace_id=trace_id)
        .order_by(models.Span.start_time.asc())
        .all()
    )


# ---------------------------------------------------------------------------
# Spans
# ---------------------------------------------------------------------------

@router.post("/spans/", response_model=schemas.SpanOut)
def create_span(payload: schemas.SpanCreate, db: DBSession = Depends(get_db)):
    trace = db.query(models.Trace).get(payload.trace_id)
    if not trace:
        raise HTTPException(status_code=404, detail="Trace not found")
    span = models.Span(**payload.model_dump())
    db.add(span)
    db.commit()
    db.refresh(span)
    return span


@router.patch("/spans/{span_id}", response_model=schemas.SpanOut)
def update_span(span_id: str, payload: schemas.SpanUpdate, db: DBSession = Depends(get_db)):
    span = db.query(models.Span).get(span_id)
    if not span:
        raise HTTPException(status_code=404, detail="Span not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(span, field, value)
    db.commit()
    db.refresh(span)
    return span
