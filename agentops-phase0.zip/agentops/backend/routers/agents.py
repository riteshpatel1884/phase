from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session as DBSession

from backend.database import get_db
from backend import models, schemas

router = APIRouter(prefix="/agents", tags=["agents"])


@router.post("/", response_model=schemas.AgentOut)
def create_agent(payload: schemas.AgentCreate, db: DBSession = Depends(get_db)):
    existing = db.query(models.Agent).filter_by(name=payload.name).first()
    if existing:
        raise HTTPException(status_code=409, detail="Agent with this name already exists")
    agent = models.Agent(**payload.model_dump())
    db.add(agent)
    db.commit()
    db.refresh(agent)
    return agent


@router.get("/", response_model=list[schemas.AgentOut])
def list_agents(db: DBSession = Depends(get_db)):
    return db.query(models.Agent).all()


@router.get("/{agent_id}", response_model=schemas.AgentOut)
def get_agent(agent_id: str, db: DBSession = Depends(get_db)):
    agent = db.query(models.Agent).get(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent
