from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session as DBSession

from backend.database import get_db
from backend import models, schemas

router = APIRouter(prefix="/sessions", tags=["sessions"])


@router.post("/", response_model=schemas.SessionOut)
def create_session(payload: schemas.SessionCreate, db: DBSession = Depends(get_db)):
    agent = db.query(models.Agent).get(payload.agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    session = models.Session(**payload.model_dump())
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


@router.get("/", response_model=list[schemas.SessionOut])
def list_sessions(db: DBSession = Depends(get_db)):
    return db.query(models.Session).all()


@router.get("/{session_id}", response_model=schemas.SessionOut)
def get_session(session_id: str, db: DBSession = Depends(get_db)):
    session = db.query(models.Session).get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session
