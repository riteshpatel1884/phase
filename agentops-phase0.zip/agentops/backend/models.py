"""
Core database models for AgentOps (Phase 0).

Tables (per project spec, section 17):
    agents
    sessions
    traces
    spans
    evaluations
    failures

Future tables (Phase 2+, not created here):
    evaluation_cases
    agent_versions
    prompt_versions
    human_feedback
"""

import uuid
import enum
from datetime import datetime

from sqlalchemy import (
    Column,
    String,
    DateTime,
    Float,
    Integer,
    ForeignKey,
    Enum,
    JSON,
    Text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from backend.database import Base


def gen_uuid():
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class RunStatus(str, enum.Enum):
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    RECOVERED = "RECOVERED"
    UNRECOVERED = "UNRECOVERED"


class SpanType(str, enum.Enum):
    AGENT = "AGENT"
    LLM = "LLM"
    TOOL = "TOOL"
    RETRIEVAL = "RETRIEVAL"
    CODE_EXECUTION = "CODE_EXECUTION"
    DATABASE = "DATABASE"
    ERROR = "ERROR"
    EVALUATION = "EVALUATION"


class SpanStatus(str, enum.Enum):
    OK = "OK"
    ERROR = "ERROR"
    RUNNING = "RUNNING"


class EvaluatorType(str, enum.Enum):
    DETERMINISTIC = "DETERMINISTIC"
    LLM_JUDGE = "LLM_JUDGE"


# ---------------------------------------------------------------------------
# Core tables
# ---------------------------------------------------------------------------

class Agent(Base):
    """An agent definition, e.g. DevPilot or ResearchOS."""

    __tablename__ = "agents"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    name = Column(String, nullable=False, unique=True)  # "devpilot" | "researchos"
    version = Column(String, default="v1")
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    sessions = relationship("Session", back_populates="agent")
    traces = relationship("Trace", back_populates="agent")


class Session(Base):
    """A logical grouping of one or more traces (e.g. one benchmark task)."""

    __tablename__ = "sessions"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    agent_id = Column(UUID(as_uuid=False), ForeignKey("agents.id"), nullable=False)
    task_description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    agent = relationship("Agent", back_populates="sessions")
    traces = relationship("Trace", back_populates="session")


class Trace(Base):
    """A complete agent run, per project spec section 8."""

    __tablename__ = "traces"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    agent_id = Column(UUID(as_uuid=False), ForeignKey("agents.id"), nullable=False)
    session_id = Column(UUID(as_uuid=False), ForeignKey("sessions.id"), nullable=True)

    status = Column(Enum(RunStatus), default=RunStatus.RUNNING)

    start_time = Column(DateTime, default=datetime.utcnow)
    end_time = Column(DateTime, nullable=True)

    total_tokens = Column(Integer, default=0)
    total_cost = Column(Float, default=0.0)
    latency_ms = Column(Float, nullable=True)

    trace_metadata = Column(JSON, default=dict)

    agent = relationship("Agent", back_populates="traces")
    session = relationship("Session", back_populates="traces")
    spans = relationship("Span", back_populates="trace", cascade="all, delete-orphan")
    evaluations = relationship("Evaluation", back_populates="trace", cascade="all, delete-orphan")
    failures = relationship("Failure", back_populates="trace", cascade="all, delete-orphan")


class Span(Base):
    """A single operation within a trace. Supports parent-child nesting."""

    __tablename__ = "spans"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    trace_id = Column(UUID(as_uuid=False), ForeignKey("traces.id"), nullable=False)
    parent_span_id = Column(UUID(as_uuid=False), ForeignKey("spans.id"), nullable=True)

    type = Column(Enum(SpanType), nullable=False)
    name = Column(String, nullable=False)

    start_time = Column(DateTime, default=datetime.utcnow)
    end_time = Column(DateTime, nullable=True)
    status = Column(Enum(SpanStatus), default=SpanStatus.RUNNING)

    input = Column(JSON, nullable=True)
    output = Column(JSON, nullable=True)
    error = Column(Text, nullable=True)
    span_metadata = Column(JSON, default=dict)

    trace = relationship("Trace", back_populates="spans")
    children = relationship("Span", backref="parent", remote_side=[id])


class Evaluation(Base):
    """An evaluation result attached to a trace (section 12-13)."""

    __tablename__ = "evaluations"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    trace_id = Column(UUID(as_uuid=False), ForeignKey("traces.id"), nullable=False)

    metric_name = Column(String, nullable=False)  # e.g. "task_success", "groundedness"
    score = Column(Float, nullable=False)
    reason = Column(Text, nullable=True)
    evidence = Column(JSON, nullable=True)
    evaluator = Column(String, nullable=True)  # e.g. "gpt-4o-judge", "deterministic"
    evaluation_type = Column(Enum(EvaluatorType), nullable=False)

    created_at = Column(DateTime, default=datetime.utcnow)

    trace = relationship("Trace", back_populates="evaluations")


class Failure(Base):
    """A classified failure, linked to the trace/span where it occurred (section 14-15)."""

    __tablename__ = "failures"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    trace_id = Column(UUID(as_uuid=False), ForeignKey("traces.id"), nullable=False)
    span_id = Column(UUID(as_uuid=False), ForeignKey("spans.id"), nullable=True)

    category = Column(String, nullable=False)  # e.g. "TEST_FAILURE", "UNSUPPORTED_CLAIM"
    message = Column(Text, nullable=True)

    recovery_status = Column(String, default="UNKNOWN")  # SUCCESS | FAILED | UNKNOWN
    retry_count = Column(Integer, default=0)
    recovery_latency_ms = Column(Float, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    trace = relationship("Trace", back_populates="failures")
