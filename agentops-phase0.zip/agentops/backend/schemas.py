"""
Pydantic schemas — the API-facing shape of our data.

Kept separate from backend/models.py (the DB/ORM shape) on purpose:
the API contract and the storage schema are allowed to evolve independently.
"""

from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, ConfigDict

from backend.models import RunStatus, SpanType, SpanStatus, EvaluatorType


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------

class AgentCreate(BaseModel):
    name: str
    version: str = "v1"
    description: Optional[str] = None


class AgentOut(AgentCreate):
    model_config = ConfigDict(from_attributes=True)
    id: str
    created_at: datetime


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------

class SessionCreate(BaseModel):
    agent_id: str
    task_description: Optional[str] = None


class SessionOut(SessionCreate):
    model_config = ConfigDict(from_attributes=True)
    id: str
    created_at: datetime


# ---------------------------------------------------------------------------
# Trace
# ---------------------------------------------------------------------------

class TraceCreate(BaseModel):
    agent_id: str
    session_id: Optional[str] = None
    trace_metadata: dict = {}


class TraceUpdate(BaseModel):
    status: Optional[RunStatus] = None
    end_time: Optional[datetime] = None
    total_tokens: Optional[int] = None
    total_cost: Optional[float] = None
    latency_ms: Optional[float] = None


class TraceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    agent_id: str
    session_id: Optional[str]
    status: RunStatus
    start_time: datetime
    end_time: Optional[datetime]
    total_tokens: int
    total_cost: float
    latency_ms: Optional[float]
    trace_metadata: dict


# ---------------------------------------------------------------------------
# Span
# ---------------------------------------------------------------------------

class SpanCreate(BaseModel):
    trace_id: str
    parent_span_id: Optional[str] = None
    type: SpanType
    name: str
    input: Optional[Any] = None
    span_metadata: dict = {}


class SpanUpdate(BaseModel):
    end_time: Optional[datetime] = None
    status: Optional[SpanStatus] = None
    output: Optional[Any] = None
    error: Optional[str] = None


class SpanOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    trace_id: str
    parent_span_id: Optional[str]
    type: SpanType
    name: str
    start_time: datetime
    end_time: Optional[datetime]
    status: SpanStatus
    input: Optional[Any]
    output: Optional[Any]
    error: Optional[str]
    span_metadata: dict


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------

class EvaluationCreate(BaseModel):
    trace_id: str
    metric_name: str
    score: float
    reason: Optional[str] = None
    evidence: Optional[Any] = None
    evaluator: Optional[str] = None
    evaluation_type: EvaluatorType


class EvaluationOut(EvaluationCreate):
    model_config = ConfigDict(from_attributes=True)
    id: str
    created_at: datetime


# ---------------------------------------------------------------------------
# Failure
# ---------------------------------------------------------------------------

class FailureCreate(BaseModel):
    trace_id: str
    span_id: Optional[str] = None
    category: str
    message: Optional[str] = None
    recovery_status: str = "UNKNOWN"
    retry_count: int = 0
    recovery_latency_ms: Optional[float] = None


class FailureOut(FailureCreate):
    model_config = ConfigDict(from_attributes=True)
    id: str
    created_at: datetime
