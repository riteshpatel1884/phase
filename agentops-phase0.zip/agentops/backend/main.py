"""
AgentOps backend — FastAPI skeleton (Phase 0).

Run with:
    uv run uvicorn backend.main:app --reload

No agent logic and no dashboard yet. This just exposes CRUD
endpoints over the trace/span/evaluation/failure data model so the
instrumentation layer (Phase 2) has somewhere to write to.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.database import Base, engine
from backend.routers import agents, sessions, traces, evaluations, failures

app = FastAPI(
    title="AgentOps API",
    description="AI Agent Evaluation, Observability & Reliability Platform",
    version="0.1.0",
)

# Frontend (Next.js) will run on localhost:3000 during development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(agents.router)
app.include_router(sessions.router)
app.include_router(traces.router)
app.include_router(evaluations.router)
app.include_router(failures.router)


@app.on_event("startup")
def on_startup():
    # Phase 0: create tables directly. From Phase 1 onward, prefer
    # Alembic migrations (see alembic/) instead of create_all.
    Base.metadata.create_all(bind=engine)


@app.get("/")
def root():
    return {
        "service": "AgentOps API",
        "status": "ok",
        "phase": "Phase 0 - Foundation",
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
