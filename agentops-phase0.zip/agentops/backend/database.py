"""
Database connection setup for AgentOps.

Uses SQLAlchemy with PostgreSQL. Connection string is read from
the DATABASE_URL environment variable (see .env.example).
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://agentops:agentops@localhost:5432/agentops",
)

# pool_pre_ping avoids "server closed the connection unexpectedly" errors
# after long idle periods (common with Neon/Supabase free tiers).
engine = create_engine(DATABASE_URL, pool_pre_ping=True)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """FastAPI dependency that yields a DB session and closes it after use."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
