Phase 3+ (Next.js) - not started yet
